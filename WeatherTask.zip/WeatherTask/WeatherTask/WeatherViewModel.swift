//
//  WeatherViewModel.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//

import Foundation
import UIKit
import Alamofire
import ProgressHUD

class WeatherViewModel: NSObject {
    
    //MARK: -- Get City Weather Info
    func getCityWeather(cityName: String,apiKey: String, viewcontroller: UIViewController, completion: @escaping (ResponseModel) -> Void) {
        let urlString = "\(APIs.baseUrl)/data/2.5/weather?q=\(cityName)&appid=\(apiKey)"
        print("url: -- \(urlString)")
        guard let url = URL(string: urlString) else { return }
        AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil)
            .responseJSON(completionHandler: { response in
                switch response.result {
                case .success(_):
                    do {
                        let data = try JSONDecoder().decode(ResponseModel.self, from: response.data!)
                        completion(data)
                    } catch  {
                        self.showAlert(message: error.localizedDescription, viewcontroller: viewcontroller)
                    }
                case .failure(let error):
                    print("error: -- \(error)")
                }
            })
    }
    
    //MARK: -- default Alert Method
    func showAlert(message: String, viewcontroller: UIViewController) {
        let alert = UIAlertController(title: "Error", message: message,         preferredStyle: UIAlertController.Style.alert)
       
        alert.addAction(UIAlertAction(title: "OK",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
        }))
        viewcontroller.present(alert, animated: true, completion: nil)
    }
    
}
