//
//  ViewController.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//

import UIKit
import MapKit
import CoreData
import SDWebImage

class ViewController: UIViewController {
    
    //MARK: -- UILabel Outlet
    @IBOutlet weak var locationNameLabel: UILabel!
    @IBOutlet weak var weatherTypeLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    //MARK: -- Variable Declare
    var locations: [UserLocation] = []
    @IBOutlet weak var serachBar: UISearchBar!
    let locationManager = CLLocationManager()
    var getLocation: String?
    var viewModel = WeatherViewModel()
    var searchResults: ResponseModel? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        serachBar.delegate = self
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
        
        
        locations = DatabaseManager.sharedManager.fetchLocation()
        print("location: \(locations.last?.name ?? "")")
        serachBar.text = locations.last?.name ?? ""
        self.searchBarTextFiledValidation(text: serachBar.text ?? "")
        
    }
    
    
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = manager.location?.coordinate else { return }
        print("latitude\(location.latitude) and longitude \(location.longitude)")
    }
}

extension ViewController: UISearchBarDelegate {
    //MARK: -- Search Button Action
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        guard let query = searchBar.text else { return }
        self.searchBarTextFiledValidation(text: query)
    }
    
    //MARK: -- Search Bar Validation
    func searchBarTextFiledValidation(text: String) {
        if text.isEmpty {
            viewModel.showAlert(message: "Please Enter Location", viewcontroller: self)
            self.locationNameLabel.text = ""
            self.weatherTypeLabel.text = ""
            self.weatherDescriptionLabel.text = ""
            self.weatherIcon.image = UIImage(named: "")
            let location = UserLocation(context: DatabaseManager.sharedManager.context)
            location.name = text
            DatabaseManager.sharedManager.saveContext()
        } else {
            viewModel.getCityWeather(cityName: text, apiKey: apiKey, viewcontroller: self) { weatherResponse in
                self.searchResults = weatherResponse
                DispatchQueue.main.async {
                    self.locationNameLabel.text = "Location: \(self.searchResults?.name ?? "")"
                    self.weatherTypeLabel.text = "Weather Type: \(self.searchResults?.weather?[0].main ?? "")"
                    self.weatherDescriptionLabel.text = "Description: \(self.searchResults?.weather?[0].description ?? "")"
                    self.weatherIcon.sd_setImage(with: URL(string: "\(APIs.iconBaseUrl)\(self.searchResults?.weather?[0].icon ?? "")@2x.png"), placeholderImage: UIImage(named: "placeholder.png"))
                }
                let location = UserLocation(context: DatabaseManager.sharedManager.context)
                location.name = text
                DatabaseManager.sharedManager.saveContext()
            }
        }
    }
}
