//
//  SecondViewController.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//

import UIKit


class SecondViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
}
