//
//  Constant.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//

import Foundation
import UIKit

let apiKey = "9b47a6077e9da0d54a58de1124154658"

struct APIs {
    static let baseUrl = "https://api.openweathermap.org"
    static let iconBaseUrl = "https://openweathermap.org/img/wn/"
}
