//
//  DatabaseManager.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//

import Foundation
import CoreData


class DatabaseManager {
    
    static var sharedManager = DatabaseManager()
    
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {

        let container = NSPersistentContainer(name: "WeatherTask")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support
    lazy var context = persistentContainer.viewContext
    func saveContext () {
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func fetchLocation() -> [UserLocation] {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserLocation")
        do {
            if let locations = try context.fetch(fetchRequest) as? [UserLocation] {
                return locations
            }
        } catch {
            print("Error occurred during fetch user location: \(error)")
        }
      
        return []
    }
}


