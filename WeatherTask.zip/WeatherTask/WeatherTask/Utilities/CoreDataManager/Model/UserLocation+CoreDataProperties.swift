//
//  UserLocation+CoreDataProperties.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//
//

import Foundation
import CoreData

extension UserLocation {
    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserLocation> {
        return NSFetchRequest<UserLocation>(entityName: "UserLocation")
    }
    @NSManaged public var name: String?
}

extension UserLocation : Identifiable {

}
