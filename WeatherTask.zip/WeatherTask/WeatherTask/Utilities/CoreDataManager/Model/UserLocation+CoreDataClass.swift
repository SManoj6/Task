//
//  UserLocation+CoreDataClass.swift
//  WeatherTask
//
//  Created by Manoj Somineni on 10/04/23.
//
//

import Foundation
import CoreData

@objc(UserLocation)
public class UserLocation: NSManagedObject {

}
